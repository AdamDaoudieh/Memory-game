import ReactDOM from 'react-dom';
import React from 'react';
import Cards from '../Cards/Cards.js';
import Menu from '../Menu/Menu.js';
import Header from '../Header/Header.js'; 
import LoginForm from '../Login/Login.js'; 
import './App.css';
import { GridSizeProvider } from '../Context/GridSizeContext.js';
import { GameProvider } from '../Context/GameContext.js';
import { TimeProvider } from '../Context/TimeContext.js';
import { ChanceProvider } from '../Context/ChanceContext.js';
import { UserProvider } from '../Context/UserContext.js';
import { WinProvider } from '../Context/WinContext.js';


function Main() {
  const [showLogin, setShowLogin] = React.useState(true);

  return (   
    <div className="main">
      <Header/>
      <div className="container">
          <Menu/>
          <Cards/>     
      </div>
      {showLogin && <LoginForm onClose={() => setShowLogin(false)} />}
    </div>
  );
}

export default function App() {
  return (
    <UserProvider>
      <GridSizeProvider>
        <GameProvider>
          <TimeProvider>
            <ChanceProvider>
              <WinProvider>
                <Main />
              </WinProvider>
            </ChanceProvider>
          </TimeProvider>
        </GameProvider>
      </GridSizeProvider>
    </UserProvider>
  );
}

ReactDOM.render(
  <App />,
  document.getElementById("root")
);