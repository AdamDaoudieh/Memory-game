// LoginForm.js
import React, { useState, useEffect, useContext } from 'react';
import './Login.css';
import { UserContext } from '../Context/UserContext';
import { WinContext } from '../Context/WinContext';
import SignUpForm from './SignUp';

export default function LoginForm() {
  const [isVisible, setIsVisible] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');
  const { setUser } = useContext(UserContext);
  const { setWin } = useContext(WinContext);
  const [showSignUpForm, setShowSignUpForm] = useState(false);

  useEffect(() => {
    const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
    setUsers(storedUsers);

    const lastLoggedInUser = JSON.parse(localStorage.getItem('lastLoggedInUser'));
    
    if (lastLoggedInUser && lastLoggedInUser.username) {
      setIsVisible(false);
      setUser(lastLoggedInUser.username);
      setWin(lastLoggedInUser.wins);
      
    } else {
      console.log('No valid lastLoggedInUser found'); 
    }
  }, [setUser, setWin]);

  const handleLogin = () => {
    const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
    const user = storedUsers.find(u => u.username === username && u.password === password);
    console.log('Login attempt for:', username); 
    console.log('Found user:', user);

    if (user && user.username) {
      setIsVisible(false);
      setError('');
      setUser(user.username);
      setWin(parseInt(user.wins) || 0);
      localStorage.setItem('lastLoggedInUser', JSON.stringify({
        username: user.username,
        wins: user.wins || 0
      }));
    } else {
      setError('Invalid username or password');
      console.log('Login failed: Invalid username or password'); 
    }
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="login-overlay">
      <div className="login-form">
        <h2 className="login-title">Welcome Back!</h2>
        <p className="login-subtitle">Please login to continue</p>
        <input
          type="text"
          placeholder="Username"
          className="chanceinput"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          className="timeinput"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button className="startbutton" onClick={handleLogin}>Login</button>
        {error && <p className="error-message">{error}</p>}
        <div className="form-footer">
          <p className="login-subtitle">Don't have an account?</p>
          <button className="signupp-button" onClick={() => setShowSignUpForm(true)}>Sign Up</button>
        </div>
      </div>
      {showSignUpForm && <SignUpForm setIsVisible={setShowSignUpForm} />}
    </div>
  );
}