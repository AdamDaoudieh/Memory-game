import React, { useState } from 'react';
import './SignUp.css';

export default function SignUpForm({ setIsVisible }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [birthdate, setBirthdate] = useState('');
  const [error, setError] = useState('');

  const handleSignUp = () => {
    const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
    
    if (!username || !password || !birthdate) {
      setError('Please fill in all fields');
      return;
    }

    if (password.length < 8 || !/[A-Z]/.test(password) || !/[^A-Za-z0-9]/.test(password)) {
      setError('Password must be at least 8 characters long and contain at least one uppercase letter and one special character');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    const userExists = storedUsers.some(u => u.username === username);
    if (userExists) {
      setError('Username already exists');
      return;
    }

    const newUser = { username, password, birthdate, wins: 0  };
    const updatedUsers = [...storedUsers, newUser];
    
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    
    console.log('New user added:', newUser);

    
    setIsVisible(false);
  };

  const handleGoBack = () => {
    setIsVisible(false);
  };

  return (
    <div className="signup-overlay">
      <div className="signup-form">
        <h2 className="signup-title">Create Account</h2>
        <p className="signup-subtitle">Please fill in the details</p>
        <input
          type="text"
          placeholder="Username"
          className="input"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          className="input"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <input
          type="password"
          placeholder="Confirm Password"
          className="input"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
        />
        <input
          type="date"
          placeholder="Birthdate"
          className="input"
          value={birthdate}
          onChange={(e) => setBirthdate(e.target.value)}
        />
        <div className="button-group">
          <button className="signup-button" onClick={handleSignUp}>Sign Up</button>
          <button className="go-back-button" onClick={handleGoBack}>Go Back</button>
        </div>
        {error && <p className="error-message">{error}</p>}
      </div>
    </div>
  );
}