import React, { useState } from 'react';

export const WinContext = React.createContext();

export const WinProvider = ({ children }) => {
    const [win, setWin] = useState(null);

    return (
        <WinContext.Provider value={{ win, setWin }}>
            {children}
        </WinContext.Provider>
    );
};