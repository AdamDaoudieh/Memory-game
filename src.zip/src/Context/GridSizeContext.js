import React from 'react';

export const GridSizeContext = React.createContext();

export const GridSizeProvider = ({ children }) => {
    const [gridSize, setGridSize] = React.useState("4x4");

    return (
        <GridSizeContext.Provider value={{ gridSize, setGridSize }}>
            {children}
        </GridSizeContext.Provider>
    );
};
