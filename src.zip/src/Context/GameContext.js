import React from 'react';

export const GameContext = React.createContext();

export const GameProvider = ({ children }) => {
    const [gameStarted, setGameStarted] = React.useState(false);

    return (
        <GameContext.Provider value={{ gameStarted, setGameStarted }}>
            {children}
        </GameContext.Provider>
    );
};
