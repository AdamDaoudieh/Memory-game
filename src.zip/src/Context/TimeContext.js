import React from "react";

export const TimeContext = React.createContext();

export const TimeProvider = ({ children }) => {
  const [Time, setTime] = React.useState();

  return (
    <TimeContext.Provider value={{ Time, setTime }}>
      {children}
    </TimeContext.Provider>
  );
};
