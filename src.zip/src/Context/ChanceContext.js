import React from 'react';

export const ChanceContext = React.createContext();

export const ChanceProvider = ({ children }) => {
    const [Chance, setChance] = React.useState();

    return (
        <ChanceContext.Provider value={{ Chance, setChance }}>
            {children}
        </ChanceContext.Provider>
    );
};
