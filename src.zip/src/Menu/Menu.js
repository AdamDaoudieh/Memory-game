import React, { useRef, useEffect, useContext, useState } from "react";
import { ChanceContext } from '../Context/ChanceContext';
import { GameContext } from '../Context/GameContext';
import { GridSizeContext } from '../Context/GridSizeContext';
import { TimeContext } from '../Context/TimeContext';
import "./Menu.css";

export default function Menu() {
  const { gridSize, setGridSize } = useContext(GridSizeContext);
  const { gameStarted, setGameStarted } = useContext(GameContext);
  const { Time, setTime } = useContext(TimeContext);
  const { Chance, setChance } = useContext(ChanceContext);

  const [timeLeft, setTimeLeft] = useState(Time * 60 + 5);
  const [showOptions, setShowOptions] = useState(true);
  const [showInput, setShowInput] = useState(true);
  const [showSubmenu, setShowSubmenu] = useState(false);
  const [buttonText, setButtonText] = useState('Start');

  const intervalRef = useRef(null);

  const handleGridSizeChange = (event) => {
    const selectedSize = event.target.value;
    setGridSize(selectedSize);
  };

  const handleTimeChange = (e) => {
    const newTime = Math.max(1, Math.floor(Number(e.target.value)));
    setTime(newTime);
  };

  const handleChanceChange = (e) => {
    const newChance = Math.max(1, Number(e.target.value));
    setChance(newChance);
  };

  useEffect(() => {
    if (Chance === 0) {
      setGameStarted(false);
      setChance(1);
    }
  }, [Chance, setGameStarted]);

  useEffect(() => {
    if (gameStarted) {
      setShowOptions(false);
      setShowInput(false);
      setButtonText('Restart');
      setShowSubmenu(true);
      setTimeLeft(Time * 60 + 5);

      intervalRef.current = setInterval(() => {
        setTimeLeft((prevTime) => {
          if (prevTime > 0) {
            return prevTime - 1;
          } else {
            clearInterval(intervalRef.current);
            setGameStarted(false);
            return 0;
          }
        });
      }, 1000);
    } else {
      setShowOptions(true);
      setShowInput(true);
      setButtonText('Start');
      setShowSubmenu(false);

      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [gameStarted, Time, setGameStarted]);

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  return (
    <div className="menu">
      {showInput && (
        <div className="menuinput">
          <p className="menutext">Time</p>
          <input
            className="timeinput"
            type="number"
            value={`${Time}`}
            placeholder="mins"
            onChange={handleTimeChange}
            min="1"
          />
          <p className="menutext">Chance</p>
          <input
            className="chanceinput"
            type="number"
            value={`${Chance}`}
            onChange={handleChanceChange}
            min="1"
          />
        </div>
      )}

      {showOptions && (
        <div className="options">
          <p className="menutext">Choose your level!</p>
          <label>
            <input
              type="radio"
              name="gridSize"
              value="2x2"
              checked={gridSize === "2x2"}
              onChange={handleGridSizeChange}
            />
            2x2
          </label>
          <label>
            <input
              type="radio"
              name="gridSize"
              value="4x4"
              checked={gridSize === "4x4"}
              onChange={handleGridSizeChange}
            />
            4x4
          </label>
        </div>
      )}

      {showSubmenu && (
        <div className="submenu">
          <h3 className="timedisplay">Time left: {formatTime(timeLeft)}</h3>
          <h3 className="chancedisplay">Chances left: {Chance}</h3>
        </div>
      )}

      <button className="startbutton" onClick={() => setGameStarted(!gameStarted)}>
        {buttonText}
      </button>
    </div>
  );
}