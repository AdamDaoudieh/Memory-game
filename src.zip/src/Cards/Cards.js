import React, { useContext } from "react";
import { GridSizeContext } from "../Context/GridSizeContext";
import { GameContext } from "../Context/GameContext";
import { ChanceContext } from "../Context/ChanceContext"; 
import { UserContext } from '../Context/UserContext';
import { WinContext } from '../Context/WinContext';
import YouWon from "../YouWon/youwon";
import "./Cards.css";


// Array of card objects
const cards = [
  {
    id: 1,
    name: "Card 1",
    image: "1.png",
  },
  {
    id: 2,
    name: "Card 2",
    image: "2.png",
  },
  {
    id: 3,
    name: "Card 3",
    image: "3.png",
  },
  {
    id: 4,
    name: "Card 4",
    image: "4.png",
  },
  {
    id: 5,
    name: "Card 5",
    image: "5.png",
  },
  {
    id: 6,
    name: "Card 6",
    image: "6.png",
  },
  {
    id: 7,
    name: "Card 7",
    image: "7.png",
  },
  {
    id: 8,
    name: "Card 8",
    image: "8.png",
  }
];

export default function Cards() {
  const { gridSize } = useContext(GridSizeContext);
  const { gameStarted, setGameStarted } = useContext(GameContext);
  const { chance, setChance } = useContext(ChanceContext);
  const { user } = useContext(UserContext);
  const { win, setWin } = useContext(WinContext);

  const [randcardsArray, setRandcardsArray] = React.useState([]);
  const [showCards, setShowCards] = React.useState(false);
  const [flippedCards, setFlippedCards] = React.useState([]);
  const [matchedCards, setMatchedCards] = React.useState([]);
  const [hasWon, setHasWon] = React.useState(false);
  const [cardsClickable, setCardsClickable] = React.useState(false);

  const correctMatches = React.useRef(0);

  //win
  React.useEffect(() => {
    if (matchedCards.length / 2 === randcardsArray.length) {
      correctMatches.current++;
      if (correctMatches.current === 2) {
        setHasWon(true);
        const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
        const userIndex = storedUsers.findIndex(u => u.username === user.username);
        if (userIndex !== -1) {
          storedUsers[userIndex].wins = (storedUsers[userIndex].wins || 0) + 1;
          localStorage.setItem('users', JSON.stringify(storedUsers));
        }
        setWin(prevWin => prevWin + 1);
        setTimeout(() => {
          restartGame();
        }, 3200);
      }
    }
  }, [matchedCards, randcardsArray]);

  function restartGame() {
    setHasWon(false);
    setGameStarted(false);
    setRandcardsArray([]);
    setShowCards(false);
    setFlippedCards([]);
    setMatchedCards([]);
    correctMatches.current = 1;

  }

  console.log(flippedCards, matchedCards);
  function handleCardClick(uniqueId) {
    if (!cardsClickable || flippedCards.length === 2 || matchedCards.includes(uniqueId)) return;

    setFlippedCards(prev => [...prev, uniqueId]);

    if (flippedCards.length === 1) {
      const firstCard = shuffledCards.find(card => card.uniqueId === flippedCards[0]);
      const secondCard = shuffledCards.find(card => card.uniqueId === uniqueId);

      const timer = setTimeout(() => {
        if (firstCard.uniqueId === -secondCard.uniqueId) {
          console.log("+1");
          setMatchedCards(prev => [...prev, firstCard.uniqueId, secondCard.uniqueId]);
        } else {
          console.log("-1");
          setChance(prev => prev - 1);
        }
        setFlippedCards([]);
      }, 1000);

      return () => clearTimeout(timer);
    }
  }

  //get right amount of cards #2
  React.useEffect(() => {
    const getRandomCards = (count) => {
      const shuffled = [...cards].sort(() => Math.random() - 0.5);
      return shuffled.slice(0, count).map(card => card.image);
    };

    const gridSizeToCardCount = {
      "2x2": 2,
      "4x4": 8,
    };

    const cardCount = gridSizeToCardCount[gridSize] || cards.length;
    setRandcardsArray(getRandomCards(cardCount));
  }, [gridSize, gameStarted]);

  //show and hide cards when game starts
  React.useEffect(() => {          
    if (gameStarted) {
      setShowCards(true);
      setMatchedCards([]); 
      setFlippedCards([]); 
      setCardsClickable(false);
      const showTimer = setTimeout(() => {
        setShowCards(false);
        setCardsClickable(true);
      }, 5000);
      return () => clearTimeout(showTimer);
    } else {
      setCardsClickable(false);
    }
  }, [gameStarted]);


  const shuffledCards = React.useMemo(() => {
    const pairedCards = randcardsArray.flatMap((card, index) => [
      { ...cards.find(c => c.image === card), uniqueId: index + 1 },
      { ...cards.find(c => c.image === card), uniqueId: -(index + 1) }
    ]);
    return pairedCards.sort(() => Math.random() - 0.5);
  }, [randcardsArray]);

  return (
    <div className={`cards-container ${gridSize === "2x2" ? "twocarddiv" : "allcarddiv"}`}>
      {shuffledCards.map((card) => (
        <img 
          key={card.uniqueId}
          className={`cards ${cardsClickable ? 'clickable' : ''}`}
          src={gameStarted && (showCards || flippedCards.includes(card.uniqueId) || matchedCards.includes(card.uniqueId)) ? card.image : 'cardcover.jpg'} 
          alt={card.name}
          onClick={() => handleCardClick(card.uniqueId)}
          style={{ cursor: cardsClickable ? 'pointer' : 'default' }}
        />
      ))}
      {hasWon && <YouWon />}
    </div>
  );
}