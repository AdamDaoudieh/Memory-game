import React from "react";
import "./youwon.css";

export default function YouWon({ gridSize }) {
  const overlayStyle = {
    width: gridSize === "2x2" ? "200px" : "400px",
    height: gridSize === "2x2" ? "200px" : "400px",
  };

  const modalStyle = {
    fontSize: gridSize === "2x2" ? "1.5rem" : "3rem",
    padding: gridSize === "2x2" ? "1rem 2rem" : "2rem 4rem",
  };

  return (
    <div className="you-won-overlay" style={overlayStyle}>
      <div className="you-won-modal" style={modalStyle}>
        <h1>You Won!</h1>
      </div>
    </div>
  );
}