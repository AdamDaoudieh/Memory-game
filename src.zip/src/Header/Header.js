import React, { useContext, useEffect, useState } from 'react';
import { UserContext } from '../Context/UserContext';
import { WinContext } from '../Context/WinContext';
import './Header.css';

export default function Header() {
  const { user, setUser } = useContext(UserContext);
  const { win, setWin } = useContext(WinContext);
  const [displayWin, setDisplayWin] = useState(win);

  useEffect(() => {
    setDisplayWin(win);
    console.log('Current win count:', win);
  }, [win]);

  const handleLogout = () => {
    localStorage.setItem('lastLoggedInUser', null);
    window.location.reload();
  };
console.log('Current user:', user);
  return (
    <div className="header">
      <h1 className="app-title">Memory Game</h1>
      <p>User: {user ? `${user} (Wins: ${displayWin})` : 'Guest'}</p>
      {user && (
        <button onClick={handleLogout} className="logout-button">
          Logout
        </button>
      )}
    </div>
  );
}